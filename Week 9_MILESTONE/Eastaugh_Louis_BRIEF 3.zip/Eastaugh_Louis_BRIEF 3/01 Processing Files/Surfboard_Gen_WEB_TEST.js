//Surfboard Generator
//..WEB Testing
//.. 12 September 2020

var xNoseL,yNoseL,xNose,yNose,xTailL,yTailL,xTail,xNoseR,yNoseR;
var xRailL,yRailL,xRailR,yRailR,xTailL,yTailL,xTail,yTail,xTailR,yTailR;
var curv;


function setup() {
  createCanvas(windowWidth,windowHeight);
    
}

function mousePressed() {

 
    
   //Setup Positions for Anchor Points 
   xNoseL = int(random(100,270)); //Nose (x)
   yNoseL = int(random(100,300));  //Nose (y)

   xNose  = int(random(270,330));  //Left Rail (x)
   yNose  = int(random(100,300)); //Left Rail (y)
  
   xNoseR = int(random(330,500)); //Right Rail (x)
   yNoseR = int(random(100,300)); //Right Rail (y)

   xRailL = int(random(80,270)); //Left Rail (x)
   yRailL = int(random(300,600)); //Left Rail (y)

   xRailR = int(random(330,520)); //Right Rail (x)
   yRailR = int(random(300,600)); //Right Rail (y)

   xTailL = int(random(100,270)); //Left Tail (x)
   yTailL = int(random(600,800)); //Left Tail (y)

   xTail  = int(random(250,350)); //Middle Tail (x)
   yTail  = int(random(600,800)); //Middle Tail (y)

   xTailR = int(random(330,550)); //Left Tail (x)
   yTailR = int(random(600,800)); //Left Tail (y)
    
   curv = int(random(-40,40));

  //Background... 
  fill(224,94,175);
  rect(0,0,windowWidth,windowHeight);
  //Curve From Nose Left to Nose Middle
  bezier(xNoseL,yNoseL,((xNoseL+xNose)/2)+curv,((yNoseL+yNose)/2)+curv,((xNoseL+xNose)/2)+curv,((yNoseL+yNose)/2)+curv,xNose,yNose);    
    
    //Curve From Nose Middle to Nose Right
  bezier(xNose,yNose,((xNose+xNoseR)/2)+curv,((yNose+yNoseR)/2)+curv,((xNose+xNoseR)/2)+curv,((yNose+yNoseR)/2)+curv,xNoseR,yNoseR);    
    
    //Curve from Nose Right To Rail Right
  bezier(xNoseR,yNoseR,((xRailR+xNoseR)/2)+curv,((yRailR+yNoseR)/2)+curv,((xRailR+xNoseR)/2)+curv,((yRailR+yNoseR)/2)+curv,xRailR,yRailR);
  
    //Curve From Rail Right to Tail Right 
  bezier(xRailR,yRailR,((xRailR+xTailR)/2)+curv,((yRailR+yTailR)/2)+curv,((xRailR+xTailR)/2)+curv,((yRailR+yTailR)/2)+curv,xTailR,yTailR);
  
    //Curve from Tail Right to Tail Middle
  bezier(xTailR,yTailR,((xTailR+xTail)/2)+curv,((yTailR+yTail)/2)+curv,((xTailR+xTail)/2)+curv,((yTailR+yTail)/2)+curv,xTail,yTail);

    //Curve from Tail Middle to Tail Left
  bezier(xTail,yTail,((xTail+xTailL)/2)+curv,((yTail+yTailL)/2)+curv,((xTail+xTailL)/2)+curv,((yTail+yTailL)/2)+curv,xTailL,yTailL);
  
    //Curve from Tail Left to Rail Left
  bezier(xTailL,yTailL,((xTailL+xRailL)/2)+curv,((yTail+yRailL)/2)+curv,((xTail+xRailL)/2)+curv,((yTail+yRailL)/2)+curv,xRailL,yRailL);
  
    //Curve from Tail Left to Nose
  bezier(xRailL,yRailL,((xRailL+xNoseL)/2)+curv,((yRailL+yNoseL)/2)+curv,((xRailL+xNoseL)/2)+curv,((yRailL+yNoseL)/2)+curv,xNoseL,yNoseL);
  }
